import sys

# return str
# takes int
def twos(number):
    if number >= 0:
        return format(number, '032b')
    else:
        positive_binary = format(-number, '032b')
        flipped_bits = ''.join('0' if bit == '1' else '1'
                               for bit in positive_binary)
        final_binary = format(int(flipped_bits, 2) + 1, '032b')
        return final_binary


def to_twos_complement(value):
    # Step 1: Check if negative
    is_negative = value < 0
    if is_negative:
        # Convert to positive equivalent
        value = -value

    # Step 2: Convert to binary without '0b' prefix
    binary_str = bin(value)[2:]

    if is_negative:
        # Step 3: Invert the bits
        inverted_str = ''.join('1' if bit == '0' else '0' for bit in binary_str)

        # Step 4: Add 1 to the inverted binary string
        # We add 1 from the right, handling carry
        result_str = list(inverted_str)
        for i in range(len(inverted_str) - 1, -1, -1):
            if result_str[i] == '0':
                result_str[i] = '1'
                break  # No carry, so break
            else:
                result_str[i] = '0'
        else:
            # If all bits were 1, prepend '1' to handle carry
            result_str.insert(0, '1')

        return ''.join(result_str)
    else:
        # If positive, just return the binary string
        return binary_str


# return int
# takes str
def to_decimal(binary_str):
    if binary_str[0] == '1':
        inverted_bits = ''.join('1' if bit == '0' else '0' for bit in binary_str)
        decimal = -1 * (int(inverted_bits, 2) + 1)
    else:
        decimal = int(binary_str, 2)
    return decimal

output_file = open(sys.argv[2], "w")


# def trim(int a):

class Simulator:

    def __init__(self, machine_code):
        self.registers = [0] * 32
        self.registers[2] = 256
        # Initialize 32 registers with zero
        self.memory = [0] * (32)
        # Initialize memory with 1MB of zeros
        self.pc = 0  # Program counter
        self.machine_code = machine_code

    def execute(self):
        while self.pc // 4 < len(self.machine_code):  # Check if pc is within the range of machine_code
            instruction = self.machine_code[self.pc // 4]  # Access instruction based on pc
            opcode = instruction[-7:]
            if opcode == "0110011":  # R-type instruction
                funct7 = instruction[:7]
                rs2 = int(instruction[7:12], 2)
                rs1 = int(instruction[12:17], 2)
                funct3 = instruction[17:20]
                rd = int(instruction[20:25], 2)
                if funct7 == "0000000":  # add, sll, slt, sltu, xor, srl,or,and
                    if funct3 == "000":  # add
                        self.registers[rd] = self.registers[rs1] + self.registers[rs2]
                        # print(self.registers[rs2])
                    elif funct3 == "010":  # slt
                        self.registers[
                            rd] = 1 if self.registers[rs1] < self.registers[rs2] else 0
                    elif funct3 == "001":  # sll
                        shift_amount = self.registers[rs2] & 0b11111  # Extract lower 5 bits of rs2
                        self.registers[rd] = self.registers[rs1] << shift_amount
                        # a = int(str(twos(self.registers[rs2])[-5:0]), 2)
                        # self.registers[rd] = self.registers[rs1] << (
                        #     a)  # Extracting lower 5 bits of rs2
                    elif funct3 == "011":  # sltu
                        self.registers[rd] = 1 if int(str(to_twos_complement(rs1)), 2) < int(
                            str(to_twos_complement(rs2)), 2) else 0  # Assuming unsigned comparison
                    elif funct3 == "011":  # sltu
                        # Determine the number of bits needed to represent rs1 and rs2
                        rs1_bits = len(format(self.registers[rs1], 'b'))
                        rs2_bits = len(format(self.registers[rs2], 'b'))
                        max_bits = max(rs1_bits, rs2_bits)

                        # Extract necessary bits from rs1 and rs2
                        rs1_binary = format(self.registers[rs1], f'0{max_bits}b')[-max_bits:]
                        rs2_binary = format(self.registers[rs2], f'0{max_bits}b')[-max_bits:]

                        # Compare binary representations bit by bit
                        for bit1, bit2 in zip(rs1_binary, rs2_binary):
                            if bit1 < bit2:
                                self.registers[rd] = 1
                                break
                    elif funct3 == "101":  # srl
                        shift_amount = self.registers[rs2] & 0b11111  # Extract lower 5 bits of rs2
                        self.registers[rd] = self.registers[rs1] >> shift_amount
                        # b = int(str(twos(rs2) % (10**5)), 2)
                        # self.registers[rd] = self.registers[rs1] >> (
                        #     b)  # Extracting lower 5 bits of rs2
                    elif funct3 == "110":  # or
                        self.registers[rd] = self.registers[rs1] | self.registers[rs2]
                    elif funct3 == "111":  # and
                        self.registers[rd] = self.registers[rs1] & self.registers[rs2]
                    elif funct3 == "100":  # xor
                        self.registers[rd] = self.registers[rs1] ^ self.registers[rs2]

                elif funct7 == "0100000":
                    if funct3 == "000":  # sub
                        if (rs1 == 0):
                            self.registers[rd] = 0 - self.registers[rs2]
                        else:
                            self.registers[rd] = self.registers[rs1] - self.registers[rs2]
                else:  # Change the error printing line.
                    print("Error Occured")
                    continue
            elif opcode == "0000011":  # I-type instruction (e.g., lw)
                # Implement I-type instruction execution
                rs1 = int(instruction[-20:-15], 2)
                rd = int(instruction[-12:-7], 2)
                imm = instruction[:-20]
                funct3 = instruction[-15:-12]
                if funct3 == "010":  # lw
                    self.registers[rd] = self.memory[(self.registers[rs1] +
                                                      to_decimal(imm) - (16) ** 4) // 4]

            elif opcode == "0010011":  # I - type instruction with diff opcode
                rs1 = int(instruction[-20:-15], 2)
                rd = int(instruction[-12:-7], 2)
                imm = instruction[:-20]
                funct3 = instruction[-15:-12]
                if funct3 == "000":  # addi
                    self.registers[rd] = self.registers[rs1] + to_decimal((imm))
                elif funct3 == "011":  # sltiu
                    if int(str(to_twos_complement(self.registers[rs1])), 2) < int(imm, 2):
                        self.registers[rd] = 1
            elif opcode == "1100111":  # jalr I-type
                rs1 = int(instruction[-20:-15], 2)
                rd = int(instruction[-12:-7], 2)
                imm = instruction[:-20]
                funct3 = instruction[-15:-12]
                if (funct3 == "000"):  # jalr
                    self.registers[rd] = self.pc + 4  # Store next instruction address in rd
                    self.pc = (self.registers[rs1] +
                               to_decimal(imm)) & ~1  # Jump to address rs1 + imm
                    self.pc -= 4

            # elif opcode == "0100011":  # S-type instruction (e.g., sw)
            #   imm1 = instruction[-32:-25]
            #   imm2 = instruction[-12:-7]
            #   rs2 = int(instruction[-25:-20], 2)
            #   rs1 = int(instruction[-20:-15], 2)
            #   funct3 = instruction[-15:-12]
            #   if funct3 == "010":
            #     address = self.registers[rs1] + to_decimal(imm1 + imm2)
            #     self.memory[address] = self.registers[rs2]
            #     # Additional code to handle memory address out of bounds or misalignment REVIEW LATER

            #     # if address < 0 or address >= len(self.memory) or address % 4 != 0:
            #     #     print("Error: Memory access out of bounds or misaligned")
            #     #     exit(1)
            elif opcode == "0100011":  # S-type instruction (e.g., sw)
                imm1 = instruction[-32:-25]
                imm2 = instruction[-12:-7]
                imm = imm1 + imm2  # Combine imm1 and imm2 to form the full 12-bit immediate value
                rs2 = int(instruction[-25:-20], 2)
                rs1 = int(instruction[-20:-15], 2)
                funct3 = instruction[-15:-12]
                if funct3 == "010":
                    imm = to_decimal(imm)  # Convert the binary immediate value to decimal
                    # imm = self.sext(imm)   # Sign-extend the immediate value to 12 bits
                    address = self.registers[rs1] + imm - 65536  # Calculate the memory address
                    self.memory[address // 4] = self.registers[
                        rs2]  # Store the value of rs2 in memory at the calculated address


            elif opcode == "1100011":  # B-type instruction (e.g., beq)
                # imm = self.sext(instruction[0] + instruction[24:32] + instruction[12:20] + instruction[1:7] + '0')

                if (instruction[-32:-7] == "0" * 25):
                    o = "0b" + twos(self.pc) + " "
                    output_file.write(o)
                    break
                # 11111110000010011001100011100011
                imm = instruction[-32] + instruction[-8] + instruction[
                                                           -31:-25] + instruction[-12:-8]

                rs1 = int(instruction[-20:-15], 2)
                rs2 = int(instruction[-25:-20], 2)
                funct3 = instruction[-15:-12]
                if funct3 == "000":  # beq
                    if self.registers[rs1] == self.registers[rs2]:
                        self.pc += to_decimal(imm[-12:] + "0")
                        self.pc -= 4
                elif funct3 == "001":  # bne
                    if self.registers[rs1] != self.registers[rs2]:
                        self.pc += to_decimal(imm[-12:] + "0")
                        self.pc -= 4
                elif funct3 == "100":  # blt
                    if self.registers[rs1] < self.registers[rs2]:
                        self.pc += to_decimal(imm[-12:] + "0")
                        self.pc -= 4
                elif funct3 == "101":  # bge
                    if self.registers[rs1] >= self.registers[rs2]:
                        self.pc += to_decimal(imm[-12:] + "0")
                        self.pc -= 4

                elif funct3 == "110":  # bltu
                    if int(str(to_twos_complement(self.registers[rs1])), 2) < int(
                            str(to_twos_complement(self.registers[rs2])), 2):
                        self.pc += to_decimal(imm[-12:] + "0")
                        self.pc -= 4
                elif funct3 == "111":  # bgeu
                    if int(str(to_twos_complement(self.registers[rs1])), 2) >= int(
                            str(to_twos_complement(self.registers[rs2])), 2):
                        self.pc += to_decimal(imm[-12:] + "0")
                        self.pc -= 4

            elif opcode == "0110111":  # U-type instruction (e.g., lui)
                imm = instruction[-32:-12]  # Extract the immediate value
                rd = int(instruction[-12:-7], 2)  # Extract the destination register
                self.registers[
                    rd] = to_decimal(
                    imm + ("0" * 12))  # Store the immediate value shifted left by 12 bits in the destination register
            elif opcode == "0010111":  # auipc
                imm = instruction[-32:-12]  # Extract the immediate value
                rd = int(instruction[-12:-7], 2)
                self.registers[
                    rd] = to_decimal(imm + "0" * 12) + self.pc



            elif opcode == "1101111":  # J-type instruction (e.g., jal)
                # Implement J-type instruction execution
                imm = instruction[0] + instruction[12:20] + instruction[11] + instruction[1:11]
                # Extract and sign-extend the immediate value
                rd = int(instruction[20:25], 2)  # Extract the destination register
                self.registers[
                    rd] = self.pc + 4  # Store the address of the next instruction in the destination register
                self.pc = self.pc + to_decimal(imm + "0")  # Jump to the calculated address with LSB set to 0
                self.pc -= 4

            elif opcode == "0000001":  # mul
                rd = int(instruction[20:25], 2)
                rs1 = int(instruction[12:17], 2)
                rs2 = int(instruction[7:12], 2)
                self.registers[rd] = self.registers[rs1] * self.registers[rs2]

            elif opcode == "1110011":  # rst and halt
                if instruction == "11100110000000000000000000001111":  # rst
                    self.registers = [0] * 32
                    self.pc = 0
                elif instruction == "11100110000000000000000000000000":  # halt
                    print("Program halted.")
                    return
                else:
                    print("Invalid instruction")
                    break
            elif opcode == "0001100":  # rvrs
                rd = int(instruction[20:25], 2)
                rs1 = int(instruction[12:17], 2)
                self.registers[rd] = int(
                    bin(self.registers[rs1])[2:].zfill(32)[::-1], 2)
            else:
                print("Invalid opcode")
                break

            self.registers[0] = 0
            self.pc += 4
            o = "0b" + twos(self.pc) + " "
            output_file.write(o)
            self.print_registers()

    def sext(self, value):
        """Sign-extend function"""
        if value & (1 << (len(value) - 1)
        ):  # Check if the most significant bit is 1 (negative number)
            return value | ~((1 << len(value)) - 1)
        else:
            return value

    def print_registers(self):
        for i in range(32):
            k = "0b" + twos(self.registers[i]) + " "
            output_file.write(k)
        output_file.write("\n")

    def print_memory(self):
        for i, k in enumerate(self.memory):
            k = "0b" + twos(k)
            m = "0x" + f"{4 * i + 16 ** 4:08x}"
            y = m + ":" + k
            output_file.write(y)
            output_file.write("\n")


# Example usage:

if __name__ == "__main__":
    with open(sys.argv[1], "r") as f:
        machine_code = f.read().splitlines()
    simulator = Simulator(machine_code)
    simulator.execute()
    simulator.print_registers()
    simulator.print_memory()